#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * @author jhlz
 * @since $DATE $TIME
 * @version 
 */
public @interface ${NAME} {
}
