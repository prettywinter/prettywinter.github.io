#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")
/**
 * @author jhlz
 * @since ${date} ${time}
 * @version 1.0.0
 */
class ${NAME} {
}