#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * @auther jhlz
 * @since $DATE $TIME
 * @version 
 */
public @interface ${NAME} {
}
